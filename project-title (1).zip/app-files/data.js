var APP_DATA = {
  "scenes": [
    {
      "id": "0-biblioteca_1",
      "name": "Biblioteca_1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 720,
      "initialViewParameters": {
        "yaw": -2.9546269929666593,
        "pitch": 0.041173533608951374,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": -2.9095467808627635,
          "pitch": 0.4859936548811614,
          "rotation": 0,
          "target": "1-biblioteca_2"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.412250281847694,
          "pitch": -0.22061785327749917,
          "title": "<br>",
          "text": "<span style=\"color: rgb(56, 72, 92); font-family: &quot;Open Sans&quot;, system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; background-color: rgb(255, 255, 255);\">El 23 de mayo de 1939 se funda, en una casa ubicada en Estado de Israel 4237, la Biblioteca Leopoldo Lugones, en homenaje al escritor y ex director de la Biblioteca Nacional. La colección se traslada tiempo después a Güemes 4601, esquina Uriarte, su sede actual. Por Ordenanza Municipal, se la renombró como </span><span style=\"font-weight: bolder; color: rgb(56, 72, 92); font-family: &quot;Open Sans&quot;, system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; background-color: rgb(255, 255, 255);\">Biblioteca Carlos Guido y Spano</span><span style=\"color: rgb(56, 72, 92); font-family: &quot;Open Sans&quot;, system-ui, -apple-system, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; background-color: rgb(255, 255, 255);\">.</span>"
        }
      ]
    },
    {
      "id": "1-biblioteca_2",
      "name": "Biblioteca_2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 720,
      "initialViewParameters": {
        "yaw": -2.701958168332286,
        "pitch": 0.0025442610078556527,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": -1.9856634630999643,
          "pitch": 0.49037700028895337,
          "rotation": 0,
          "target": "2-biblioteca_3"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.0428128878711362,
          "pitch": 0.01132546442739546,
          "title": "Sala Principal",
          "text": "https://catalogobibliotecas.buenosaires.gob.ar/pergamo/opac.php"
        }
      ]
    },
    {
      "id": "2-biblioteca_3",
      "name": "Biblioteca_3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 720,
      "initialViewParameters": {
        "yaw": -2.853650211560737,
        "pitch": 0.06859808497927133,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
